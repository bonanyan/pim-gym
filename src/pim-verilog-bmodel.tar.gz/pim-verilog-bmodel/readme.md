
## Files

```
.
├── doc
│   ├── APIM_AddressMap.pdf  //address map of apim
│   └── DPIM_AddressMap.pdf  //address map of dpim
├── makefile  //top entry
├── readme.md //readme
└── src
    ├── APIM_tb.v //testbench for APIM.v
    ├── APIM.v //design (behavioral model) of APIM
    ├── DPIM_tb.v //testbench for DPIM.v
    ├── DPIM.v //design (behavioral model) of DPIM
    └── plt.tcl //gtkwave ploting configuration, used in "make plot"

```

## To Run

```bash
make apim
make dpim
make plot
make clean

```


