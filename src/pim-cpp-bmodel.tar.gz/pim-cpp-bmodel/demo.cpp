#include <iostream>

int func(int x) {
    return x+1;
}

// demo, not executable now: using load/store function to interface PIM into system
// I use my Apple Sillicon (ARM ISA) to generate demo.s in the folder
extern int pim_igemv(int x){
    asm("str	w0, [x0, #12] \n\t\
    ldr w0, label1\n\t\
    ldr w1, label2\n\t\
    "); //find "InlineAsm Start" in the generated demo.s
    return x+1;
}

int main()
{
    int n = pim_igemv(5);
    // extended inline assembly
    std::cout << "n = " << n << std::endl; // flush is intentional
}
