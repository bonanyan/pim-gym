#include <iostream>
#include "tictoc.cpp"
#include "pim.cpp"
using namespace std;

// Main as Test
int main() {
    int m = 2, n = 3; // matrix dimensions

    //-------declare a with malloc m size as integer-------
    int *x = (int*)malloc(n*sizeof(int));
    int *y = (int*)malloc(m*sizeof(int));
    int *a = (int*)malloc(m*n*sizeof(int));
    
    //-------generate random numbers to fill x, y and a-------
    for(int i = 0; i < n; i++){
        // generate x as random number between 1 and 10
        x[i] = rand() % 10 + 1;
    }
    for(int i = 0; i < m*n; i++){
        a[i] = rand() % 10 + 1;
    }

    //-------call pim_igemv-------
    pim_igemv(m, n, a, x, y);   

    //-------print vector x-------
    cout << "x: [";
    for (int i = 0; i < n; i++) {
        cout << x[i] << ",";
    }
    cout << "]" << endl;

    //-------print matrix a as an matrix-------
    cout << "a:" << endl;
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            cout << a[i*m+j] << " ";
        }
        cout << endl;
    }
    cout << endl;

    //-------print vector y-------
    cout << "y: [";
    for (int i = 0; i < m; i++) {
        cout << y[i] << ",";
    }
    cout << "]" << endl;

    //-------free memory & return-------
    free(x);free(y);free(a);

    return 0;
}

