//------------ cpp behavioral model -------
// PIM is an acronym for Processing-In-Memory
// Level 2 BLAS w/ PIM

// xgemv: Y := A*X, dimention: A[M*N], X[N*1], Y[M*1]
// int igemv
void pim_igemv( int M, 
                int N,
                int *A, 
                int *X,
                int *Y
)	//use PIM macro, the following operator costs 32 clock_cycle (for 1GHz processor, 32ns)
{
    tic();
    for(int i = 0; i < M; i++){
        Y[i] = 0;
    }

    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            Y[i] += A[M*i+j] * X[j]; //default A is row-major order
        }
    }
    toc();
}

// single-precision sgemv
void pim_sgemv( int M, 
                int N,
                float *A, 
                float *X,
                float *Y
)	//use PIM macro, the following operator costs 32 clock_cycle (for 1GHz processor, 32ns)
{
    tic();
    for(int i = 0; i < M; i++){
        Y[i] = 0;
    }

    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            Y[i] += A[M*i+j] * X[j]; //default A is row-major order
        }
    }
    toc();
}