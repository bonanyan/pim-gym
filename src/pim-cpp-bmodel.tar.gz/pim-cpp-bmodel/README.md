# README

## Files:
```
.
├── example_float.cpp   // float pim behavioral model demo, main entry
├── example_int.cpp     // integer pim behavioral model demo, main entry
├── pim.cpp             // pim behavioral models in C++
└── tictoc.cpp          //timer function
```
## To run:
- Run integer PIM demo:
```
make
```
- Run float PIM demo: (basically the same with the integer example in behavioral, but completely different in the hardware/IC design)
```
make float
```

- cleanup generated .out files
```
make clean
```

